<?php

@include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<section class="about">

   <div class="row">

      <div class="box">
         <img src="images/about-img-1.png" alt="">
         <h3>why choose us?</h3>
         <p>We handpick the best produce and groceries so you get only the freshest items every time and Your groceries, delivered to your doorstep quickly and safely—right when you need them.</p>
         <a href="contact.php" class="btn">contact us</a>
      </div>

      <div class="box">
         <img src="images/about-img-2.png" alt="">
         <h3>what we provide?</h3>
         <p>Crisp, juicy, and hand-selected—straight from farm to your doorstep,From rice and flour to oils and spices, we’ve got your kitchen essentials covered.</p>
         <a href="shop.php" class="btn">our shop</a>
      </div>

   </div>

</section>

<section class="reviews">

   <h1 class="title">clients reivews</h1>

   <div class="box-container">

      <div class="box">
         <img src="images/pic-1.png" alt="">
         <p>"Super convenient and always fresh! I love how easy it is to order my weekly groceries—everything arrives on time and in perfect condition."</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>— Riya M.</h3>
      </div>

      <div class="box">
         <img src="images/pic-2.png" alt="">
         <p>"The fruits and veggies are top quality, better than my local market. Plus, the delivery is super fast!"</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>— Karan S.</h3>
      </div>

      <div class="box">
         <img src="images/pic-3.png" alt="">
         <p>"I was impressed with how well everything was packed. No squished tomatoes or leaking bags. Great job!"</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>— Aditi P.</h3>
      </div>

      <div class="box">
         <img src="images/pic-4.png" alt="">
         <p>"Their customer service is so responsive and friendly. I had an issue with an item once, and it was sorted within hours."</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>— Neha T.</h3>
      </div>

      <div class="box">
         <img src="images/pic-5.png" alt="">
         <p>"They have everything I need—from pantry staples to fresh fish. It’s like a full supermarket right on my phone!"</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>— Ravi J.</h3>
      </div>

      <div class="box">
         <img src="images/pic-6.png" alt="">
         <p>"Ordering groceries has never been this easy. The website is clean, simple, and works great even on my mobile."</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>— Meera D.</h3>
      </div>

   </div>

</section>









<?php include 'footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>